<?php
   require_once("controlador.php");

   cerrar_sesion();

   header("Location: ../index.php");
?>
