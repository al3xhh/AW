<?php
   header("Location: ../src/accesodenegado.html");
 ?>
